
 //Author : kade Sole
 //Program : hw4, q4
//Salespeople of a company are paid a fixed salary plus a commission based on sales. Base
// is $200 and commission is 9% of their gross weekly sale. Develop a C++ program that
//uses a while statement to input each salesperson�s gross sales for last week and calculates and
//displays his earnings. If gross sales entered is -1, the program quits.

//pseudocode 1) initiate while statement with an option to break out if user inputs -1 2) inside while body collect the total sales from the user for i salesmen
// 3) use the total sales and base commission of 200$ to calculate the weekly income 4) return this value to the user and continue the loop

#include <iostream>

using namespace std;


int main(){

int x, i;
float salary, income;


i = 1;
while (i != -1){
    cout << "\nEnter sales for Salesmen #" << i << " (Enter -1 to quit)";
    cin >> income;
    if (income == -1){
        cout << "Thank you for using our program!";
        break;}
    salary = 200 + (income * .09);
    cout << "salary for Salesman #" << i << " is " << salary << endl;
    i++;

}

system("pause");
return 0;
}

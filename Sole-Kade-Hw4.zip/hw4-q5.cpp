
 //Author : kade Sole
 //Program : hw4, q5
//Write a program that reads in the size of a square and then prints a hollow square of that
//size out of asterisks and blanks. Your program should work for squares of all sizes between 1
//and 20. If the input is greater than 20 or less than 1 use 20 or 1, retrospectively.


//pseudocode 1) Gather the size of the square from user 2) initiate loop, make sure that the input is withing (1,20) 3) begin nested loop to calculate where to fill in * and where to fill in " "
// 4) return this back to user should make a square with an empty inside

#include <iostream>

using namespace std;


int main(){
//Declare variables
int i,j,n;
//Gather the Size of the square from user
cout<<"Enter size of square(1-20)";
cin>>n;
//initiate while statement
while(n<1||n>20)
{cout<<"invalid entry";
cout<<"Enter size of square(1-20)";
cin>>n;
}
// nested for loop to see if j < n if it is then print *
for(i=0;i<n;i++)
if(i==0||i==n-1)
{for(j=0;j<n;j++)
cout<<"*";
cout<<endl;
}
// else statement to see if j < n-2 if it is then print a space and then a star with a new line
else
{cout<<"*";
for(j=0;j<n-2;j++)
cout<<" ";
cout<<"*\n";
}
system("pause");
return 0;
}


 //Author : kade Sole
 //Program : hw4, q6
//Extra credit (10%) :Extend q2 above to accept variable length binary integer up to 10
//digits.

//My question 2 already did that however, 1) Collect binary number 2) initiate while loop to begin the calculation of the decimal form of binary number input
// 3) enter nested loop to preform the calculations 4) return the calculations that you calculated back to the user 5) allow the user to leave the loop by entering -1
#include <iostream>
# include <math.h>
using namespace std;


int main(){
int i, num, sum, decimal = 10, digit, binary = 2; //used to declare the variables that are needed


cout << "Enter a binary number to convert to decimal form(-1 to exit): \n"; //collect binary input from user
cin >> num;

    while(num !=-1){ //initiate the while loop, let them exit with -1
        sum = 0;
        i = 0;

        cout << "Decimal equivalent of " << num << " is: "; //begins printing the statement before calculating the decimal form of the number


        while(num > 0) //start nested loop to calculate the decimal form of number
        {
            digit = num % decimal;    //preform calculation of decimal form of binary input
            num = num / decimal;
            sum += digit * pow(binary,i);
            i++;
        }
        cout << sum; //finish the cout statement of line 32 with the decimal form that we just calculated


        cout << "\n\nEnter a binary number to convert to decimal(-1 to exit): "; //since initial input was started before while statement we have to put this in here so they can calculate another
        cin >> num;
    }
system("pause");
return 0;
}

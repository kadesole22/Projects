
 //Author : kade Sole
 //Program : hw4, q2
//Input an integer containing only 0s and 1s (i.e. binary integer) and prints its decimal equiv-
//alent. Use the modulus and division operators to pick off the binary digits as before. You
//only need to handle a fixed-length, 5-digit binary integer for this question. Assume that the
//user will always enter a 5-digit integer.

//psuedo code 1) gather an integer containing only 0s and 1s 2)calculate the decimal equivalent of the input 3)return the decimal equivalent back to the user






#include <iostream>
#include <math.h>  //this is needed because i could not figure out how to take variable from and raise it to i power without using the pow function
using namespace std;


int main(){
int i, num, sum, decimal = 10, digit, binary = 2; //used to declare the variables that are needed


cout << "Enter a binary number to convert to decimal form(-1 to exit): \n"; //collect binary input from user
cin >> num;

    while(num !=-1){ //initiate the while loop, let them exit with -1
        sum = 0;
        i = 0;

        cout << "Decimal equivalent of " << num << " is: "; //begins printing the statement before calculating the decimal form of the number


        while(num > 0) //start nested loop to calculate the decimal form of number
        {
            digit = num % decimal;    //preform calculation of decimal form of binary input
            num = num / decimal;
            sum += digit * pow(binary,i);
            i++;
        }
        cout << sum; //finish the cout statement of line 32 with the decimal form that we just calculated


        cout << "\n\nEnter a binary number to convert to decimal(-1 to exit): "; //since initial input was started before while statement we have to put this in here so they can calculate another
        cin >> num;
    }





return 0;
}


 //Author : kade Sole
 //Program : hw4, q3
//The process of finding the largest and smallest numbers is used frequently in computer ap-
//plications. Write a C++ program that uses a while statement to determine and print the
//largest and the second largest number of x integers entered by the user, where x should also
//be input by the used


//pseudocode  1) gather an input from user to see how many numbers they want 2) initiate a while loop using the input as a condition for the while loop 3) calculate the largest number and 2nd largest
// 4)return these numbers to the user




#include <iostream>

using namespace std;


int main(){

int inp[20], x; // input
int largest,largest_2; // largest numbers that plan on being returned
int i;

cout << "How many numbers do you have?"; // statement to see how many numbers user wants
cin >> x;

largest = 0;
largest_2 = 0;

i = 0;
while(i < x){
    cout  << "Enter number" << i+1 << " "; //part of the loop that collects number at i loops
    cin >> inp[i];
    if(inp[i] > largest_2)
        if(inp[i] > largest)    // if statements to find largest number and 2nd largest number
    {
        largest_2 = largest;
        largest = inp[i];
    }
        else largest_2 = inp[i]; // an else statement for if the if statement is not met
        i++;
}
cout << "\nThe largest number is equal to: " << largest << "\n The second largest number is equal to: " << largest_2 <<endl;  // print statement to give the largest and 2nd largest numbers back to user
system("pause");

return 0;
}

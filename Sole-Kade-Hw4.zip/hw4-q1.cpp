
 //Author : kade Sole
 //Program : hw4, q1
//Drivers are concerned with the mileage obtained by their cars. One driver has kept track of
//several tankful of gasoline by recording miles driven and gallons used for each tankful. De-
//velop a c++ program that uses a while statement to input the miles driven and gallons used
//for each tankful. The program should calculate and display the miles per gallon obtained
//for each tankful and print the combined miles per gallon obtained for all tankfuls up to that
//point. If the mileage is -1, the program quits.

//pseudo code 1) collect mileage and gallons used for trip 2)enter while loop that calculates MPG for the trip 3) inside for loop also calculate the MPG for all trips combined
// 4) if -1 is entered, break out of loop 5) return these values that were calculated to user







#include <iostream>
using namespace std;


int main(){




    float mileage, gallons, x, all_miles = 0.0, all_gallons = 0.0, mpg;
    x = 1;
    cout << "\nEnter Mileage for Trip #" << x << " :(-1 to quit)\n"; // collect mileage for the trip from user
    cin >> mileage;


    while(mileage != -1){ //initiate while loop


        cout << "\nEnter Gallons for Trip #" << x << " :\n"; // collect gallons for the trip from user
        cin >> gallons;

        mpg = mileage / gallons; // calculates the miles per gallon on current trip

        cout << "MPG for Trip #" << x << " :" << mpg; // returns the mpg to user

        all_miles = all_miles + mileage; //calculates the sum of all miles drove
        all_gallons = all_gallons + gallons; //calculates the sum of all gallons used

        cout << "\nMPG for all trips so far is " << all_miles / all_gallons; // returns the MPG for all trips so far to user
        x++;
        cout << "\nEnter Mileage for Trip #" << x << " :(-1 to quit)\n"; // collect mileage for the trip from user
        cin >> mileage;
    if(mileage == -1){
        cout << "Thank you for using our MPG program!"; // initiates a break statement to get out of loop
        }
}
return 0;
}


 //Author : kade Sole
 //Program : hw5, q1
// A palindrome is a number or a text phrase that reads the same backwards as forwards. For
//example, 12321, 3456543, etc. Write a program that reads in a five-digit integer and deter-
//mines whether it is a palindrome. Hint: use the integer division and modulus operator to
//separate the number into its individual digits.

//pseudocode 1. initiate variables 2. collect input from user 3.initiate while loop to make sure that input is 5 digits 4. once its insured that its 5 digits initiate scond while loop
//5.preform the loop calculations to check if it is a palindrome 6. return the calculation  back to the user


#include <iostream>
using namespace std;


int main(){
//initiate variables
int i=10,x=10000,num,high,low;
//collect input form user
cout<<"Enter a 5-Digit integer: ";
cin>>num;
//check to make sure input is 5 digits
    while(num<10000||num>99999)
        {cout<<"number must be 5 digits\n";
        cout<<"Enter a 5-Digit integer:";
        cin>>num;
        }
cout<<num;
//calculate to see if it is a palindrome
    while(num>9)
        {low=num%i;
        high=num/x;
            if(low!=high)
                {cout<<" is NOT a Palindrome\n";
                system("pause");
                return 0;
                }
        num=(num-(high*x))/10;
        x/=100;
        }
//return calculation to user
cout<<" is a Palindrome\n";
system("pause");
return 0;
}

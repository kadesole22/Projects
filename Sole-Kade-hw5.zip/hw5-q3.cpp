
 //Author : kade Sole
 //Program : hw5, q3
// Pythagorean Triples: A right triangle can have sides that are all integers. A set of three
//integer values for the sides of a right triangle is called a Pythagorean triple. These three
//sides must satisfy the relationship that the sum of the squares of two of the sides is equal
//to the square of the hypotenuse. Find all unique Pythagorean triples for side1, side2 and
//hypotenuse, all no longer than 500. How many are there? Note that this problem specifically
// you to exclude the duplicates, unlike the one on p.167 of the slides. For example, if you
//were to check all unique Pythagorean Triples less than 5 (rather than 500) your output must
//be


//pseudocode 1. initiate function 2.create a function to calculate triples with duplicates, how many times innermost loop is executed. number of non duiplicates 3.call function to return calculations
//to user
#include <iostream>
#include <math.h>
using namespace std;
//declaration of the function
void pythagoreanTriplet(){
//variables used inside the function
const int MAX_SIDE_LENGTH=500;
int innerMostLoopCount=0;
int duplicatesCount=0;
int tripletCount=0;
//initiate nested for loop
    for(int side1=1; side1<=MAX_SIDE_LENGTH;side1++){
        for(int side2=1; side2<=MAX_SIDE_LENGTH;side2++){

            for(int side3=1; side3<=MAX_SIDE_LENGTH;side3++){
                if(side2<=side1 || side3<=side1 || side3<=side2)duplicatesCount+=1;
                innerMostLoopCount+=1;
                if((side3*side3)==(side1*side1+side2*side2)){
                tripletCount+=1;

                }
            }
        }
    }
    //return calculations back to user
    cout<<"Number of Pythagorean Triples with duplicates : "<<tripletCount<<endl;
    cout<<"The Innermost for loop is entered "<<innerMostLoopCount<<" times.\n";
    cout<<"Number of Pythagorean Triples (no duplicates) : "<<tripletCount/2<<endl;
    cout<<"The Innermost for loop is entered "<<innerMostLoopCount-duplicatesCount<<" times.\n";
}

int main(){
//call the function
pythagoreanTriplet();




}

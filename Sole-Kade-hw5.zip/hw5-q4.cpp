
 //Author : kade Sole
 //Program : hw5, q4
 //Write a program that reads a nonnegative integer and computes and prints its factorial.
//Do not use scientific notation for displaying the result.
//(b) Write a program that estimates the value of mathematical constant e by using the
//formula:
//

//pseudocode 1. Create 2 different functions to calculate the factorial and one that calculates e with a desired accuracy
// 3.prompt user for the number 4.calculate the factorial of the user input 5.return this to user 6.collect the desired accuracy from user
//7.calculate using the desired accuracy and return to user
#include <iostream>
#include <iomanip>
using namespace std;
//declaration of the variable
double factorial(double n);
//declaration of the variable
double e(int terms);


int main()
{   //declaration of these variables used to represent user inputs
    double n;
    int k;
    //collect input from user
    cout<<"Number for Factorial : ";
    cin>>n;
    //calculate factorial of user input
    cout<< n<< "! = "<<setprecision(10)<<fixed<<factorial(n)<<endl;

    //collect input from user
    cout<<"Desired Accuracy for \"e\"(number of terms in the series): ";
    cin>>k;
    //calculate using the input from user and return calculations
    cout<<"e with 10 terms = "<<setprecision(10)<<fixed<<e(k)<<endl;

    system("pause");
    return 0;
}
double factorial(double n) //function to calculate factorial
{
    int i;
    double nf=1;
    for(i=2;i<=n;i++)
    nf*=i;
    return nf;
}
double e(int terms) //function to calculate with the desired accuracy
{
    long double val=1;
    int i;
    for (i=1;i<terms;i++)
    val=val+1/factorial(i);
    return val;
}





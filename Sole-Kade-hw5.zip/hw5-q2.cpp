
 //Author : kade Sole
 //Program : hw5, q2
// A person invests $10000.00 in a savings account. Assuming that all interest is left on deposit
//in the account, calculate and print the amount of money in the account at the end of 10 years
//for interest rates of 1, 2, 3, 4, 5, 6, 7, 8, 9 and 10%. Use the following formula for determining
//these amounts:


//pseudo code 1.intial investment is 10000$ 2. calculate interest rates of 1-10 for 10 years 3. return calculations to user
#include <iostream>
#include <math.h>
using namespace std;


int main(){
//initiate variables
float interest = 10000;
int x = 1;
double total;
float rate = .01;
//print header statement
cout << "Rate       Amount at the end of 10th year\n====       ================================\n";
//enter while loop to calculate interest rates and return the total to user
while (x <= 10){
    total = interest * pow(1 + rate, 10);
    cout << rate << "               " << total << "\n";

    rate += .01;
    x++;
    }


return 0;
}

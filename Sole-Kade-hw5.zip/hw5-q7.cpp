
 //Author : Kade Sole
 //Program : hw5, q7

 //In cryptarithmetic puzzles, mathematical equations are written using letters. Each letter can
//be a digit from 0 to 9, but no two letters can be the same. Customarily, distinct letters stand
//for different digits Here is a sample problem:


//pseudocode 1.set a condition for the variables variables 2.calculate the values of T,O,G,D 3.return these values to user

#include<iostream>
using namespace std;
int main()
{   //declare variables
    int x[4],carry=0;
    int t,o,g,d,i;
        //for loops that check the condition and incriment
        for(t=0;t<=9;t++)
        for(o=0;o<=9;o++)
        for(g=0;g<=9;g++)
        for(d=0;d<=9;d++)
            //if statement to preform calculations
            if(!(t==o||t==g||t==d||o==g||o==d||d==g))
            {
                carry=0;
                x[3]=(o*4+carry)%10;
                carry=(o*4+carry)/10;
                x[2]=(o*4+carry)%10;
                carry=(o*4+carry)/10;
                x[1]=(t*4+carry)%10;
                x[0]=(t*4+carry)/10;
                    //once conditions have been met, enter this loop to return values to user
                    if(x[0]==g&&x[1]==o&&x[2]==o&&x[3]==d)
                    {
                        cout<<"The values are: T = "<<t<<" O = ";
                        cout<<o<<" G = "<<g<<" D = "<<d<<endl;
                    }
            }

    system("pause");
    return 0;
}


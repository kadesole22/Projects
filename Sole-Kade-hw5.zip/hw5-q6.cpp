
 //Author : kade Sole
 //Program : hw5, q6

 //Write a program that finds and prints all of the prime numbers between 3 and 1000. Print
//them and display the total prime numbers between 3 and 1000.

//pseudocode 1.calculate all prime numbers from 3-100 2. calculate how many prime numbers i calculated 3.return the prime numbers and how many prime numbers back to user
// make sure to start a new line every 8 prime numbers

#include <iostream>
#include<iomanip>
using namespace std;

    int main()
    {
        //initiate variables
        int i,j,factors,count=0,line=1;
        //enter for loop
        for(j=3;j<=1000;j++)
        {   //calculate prime numbers
            factors=0;
            for(i=1;i<=j;i++)
                if(j%i==0)
                factors++;
                if(factors==2)
                {   //calculate how many prime numbers there is
                    cout<<setw(8)<<j;
                    count++;
                    if(line%8==0)
                    cout<<endl;
                    line++;
                }
        }
    //return calculations to user
    cout<<"\n\nThere are "<<count<<" prime numbers between 3 and 1000\n";
    system("pause");
    return 0;
    }


 //Author : Kade Sole
 //Program : hw5, q8

 //Extra credit (3%): Extend q6 above to get the lower and upper bounds for the range to
//look for the prime numbers.

//pseudocode 1.collect the lower and upper bound as input from user 2. calculate the prime numbers within the bound the lower and upper bound
// 3.return the number of prime numbers back to user as well as a list of them

#include <iostream>
#include<iomanip>
using namespace std;


int main()
{   //declare variables
    int max,min;
    int i,j,factors,count=0,line=1;
    //collect lower bound from user
    cout<<"Lower Bound = ";
    cin>>min;
    //collect upper bound from user
    cout<<"Upper Bound = ";
    cin>>max;
        for(j=min;j<=max;j++)
        {   //calculate prime numbers between lower and upper bound
            factors=0;
            for(i=1;i<=j;i++)
            if(j%i==0)
            factors++;
            if(factors==2||j==1)
            {   //print the list of prime numbers
                cout<<setw(8)<<j;
                count++;
                if(line%8==0)
                cout<<endl;
                line++;
            }
        }
    //print the number of prime numbers between the min and max bound
    cout<<"\n\nThere are "<<count<<" prime numbers between "<<min<<" and "<<max<<endl;
    system("pause");
    return 0;
}

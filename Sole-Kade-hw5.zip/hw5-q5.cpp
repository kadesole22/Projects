
 //Author : kade Sole
 //Program : hw5, q5

 //Write a program that computes the value of e^x by using the formula
 //Prompt the user for the desired accuracy of e, i.e. the number of terms in the summation
//and the power of �e�. Use 10 digits of precision to display the result.


//pseudocode 1.prompt the user for desired accuracy of e 2.use 10 digits of precision to display the result 3.collect the exponent of e 4.calculated using the exponent
//and accuracy user input 5.return this calculation back to the user

#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;
//initiate function
double FACT(double);

int main()
{
    //declare variables
     int x,i;
    double n,sum;
    //collect input from user
    cout<<"Enter the exponent of \"e\": ";
    cin>>x;
    //collect desired accuracy from user
    cout<<"Desired Accuracy (number of terms in the series): ";
    cin>>n;
    //calculate with the desired accuracy
    sum=1;
    for(i=1;i<n;i++)
    //call to the function
    sum+=(pow(x,i))/FACT(i);
    //return the new sum to user
    cout<<"e^"<<x<<" with "<<n <<" terms is "<<setprecision(10)<<fixed<<sum<<endl;
    system("pause");
    return 0;
}

double FACT(double n)
{
    int j;
    double sum=1;
    for(j=1;j<=n;j++)
    sum=sum*j;
    return sum;
}


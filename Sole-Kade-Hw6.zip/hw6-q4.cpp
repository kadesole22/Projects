
 //Author : Kade Sole
 //Program : hw6 Q4



//Question Write a program that uses for statements to print the following separately, one below the
//other. Use for loops to generate the patterns. All asterisks should be printed by a single
//statement of the form ( cout << �*�; and cout << " " )

//pseudocode 1. We need to make four seperate four loops one for each shape 2. We need to have 10 rows for each shape so we must use a nested loop the outer loop being 10 rows, inner being shape
//3. We must return these shapes back to the user

#include <iostream>

using namespace std;

int main()
{
int i, j, k, l, m;
cout<<"All four patterns:"<<endl;

for(i=0;i<10;i++)
    { //1st Pattern
    int n=10;
    for(int i=0;i<n;i++)
    {
        //Loop to print *
        for(int j=0;j<(i+1);j++)
        {
            cout<<"*";
        }
        cout<<endl;
    }
    cout << "\n";


    //2nd Pattern
    for(int i=n-1;i>=0;i--)
    {
        //Loop to print *
        for(int j=0;j<i+1;j++)
        {
            cout<<"*";
        }
        cout<<endl;
    }

    //3rd pattern
    for(int i=0;i<n;i++)
    {
        //Loop to print spaces in each row
        for(int j=0;j<2*i;j++)
        {
            cout<<" ";
        }
        //Loop to print *
        for(int j=0;j<(n-i-1)+1;j++)
        {
            cout<<"*";
        }
        cout<<endl;
    }

    //4th pattern
    for(int i=0;i<n;i++)
    {
        //Loop to print spaces in each row
        for(int j=0;j<2*(n-i-1);j++)
        {
            cout<<" ";
        }
        //Loop to print *
        for(int j=0;j<(i)+1;j++)
        {
           cout<<"*";
        }
        cout<<endl;
    }
return 0;
}
}


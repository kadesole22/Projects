
 //Author : Kade Sole
 //Program : hw6 Q5

 //Question Write a simple calculator program that adds, subtracts, multiplies and divides. When the
//program is run, it initializes the result to 0. The user can then type in an operator and
//number. The result is updated and displayed. The following operators are valid

//create a chart that lets users select what kind of operation to user 2. use this operation they selected for calculations 3. Collect users number they wish to use with calculation
// 3. Let the loop continue going after one calculation 4.Continually return the new result back to user 5. Let them quit using Q or q

#include<iostream>
using namespace std;

int main()
{
    //declaration of variables
    float result = 0.0,val;

    char ch; //to get operation choice from user

    for(;;) //infinite loop
    {   //display table with options to chose from
        cout<<"\nResult: "<<result; //displaying result
        cout<<"\nEnter operator from the table below, Q or q to quit, h or H for help:\n";
        cout<<"\tOperator Meaning\n";
        cout<<"\t-------- -----------\n";
        cout<<"\t+\t Addition\n\t-\t Subtraction\n\t*\t Multiplication\n\t/\t Division\n";
        cout<<"\t---------------------\n";
        cin>>ch; //accepting user choice

        //Option to exit loop with q
        if(ch == 'q')
        exit(0); //exits the program if q pressed
        if(ch == 'Q')
        exit(0);
        //collect value from user
        cout<<"Enter the value: ";
        cin>>val; //input value

        switch(ch)
        { //computations based on choice
            case '+': cout<<result<<" + "<<val;
            result += val;
            break;

            case '-': cout<<result<<" - "<<val;
            result -= val;
            break;

            case '*': cout<<result<<" * "<<val;
            result *= val;
            break;

            case '/': if(val == 0)
            { //handling divide by zero exception
            cout<<"\nDivide by zero operation ignored";
            }
            else{
            cout<<result<<" / "<<val;
            result += val;
            }
            break;

        deafult: cout<<"\nInvalid entry! Please retry";
}
}
    return 0;
}

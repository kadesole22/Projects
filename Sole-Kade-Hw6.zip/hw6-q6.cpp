
 //Author : Kade Sole
 //Program : hw6 Q6

//Question Write a function IntegerPower(base, exponent) that returns the value of base^exponent.

//Pseudocode 1. Create a function that collects base and exponent as arguments and calculates base^exponent. 2.Use a for loop to iterate exponent times while multiplying base by itself each time
//3. Make sure to collect base and exponent as inputs from the user

#include <iostream>
#include<iomanip>
using namespace std;
//initialization of function
double integerPower(int base, int exponent);

int main()
 {  //declaration of variables
    int base, exponent;
    //collect base and exponent from user
    cout << "Enter the base : ";
    cin >> base;
    cout << "Enter the exponent : ";
    cin >> exponent;
    //call to function to calculate the base^exponent
    cout << base << " to the power of " << exponent << " is " << setprecision(14) << integerPower(base, exponent) << endl;
    return 0;
}
//Function Definition
double integerPower(int base, int exponent)
{   //result is the final value we return
    double result = 1;
    //create a for loop that iterates for how many exponent values where enters.
    // If the base is 3 and exponent is 4 take 3*1 store result and repeat loop 3*3
    int i;
    for(i = 0; i < exponent; ++i)
    {
    result *= base;
    }
    return result;
}

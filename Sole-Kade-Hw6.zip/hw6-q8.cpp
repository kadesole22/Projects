
 //Author : Kade Sole
 //Program : hw6 Q8

 //Question - Write a program to display the area of a rectangle after accepting its length and width from
//the user by means of the following functions:
//getLength � ask user to enter the length and return it as double
//getWidth � ask user to enter the width and return it as double
//getArea � pass width and length, compute area and return area
//displayArea � pass area and display it in this function


//Pseudocode Create four functions. Function 1- collect length from user Function 2- collect width from user Function 3- calculate w * l and return value Function 4 - Return value calculated
// with function 3 back to user In the Main() function make sure that you call all four of these functions as well as creating the format that is required.

#include <iostream>
#include <iomanip>
using namespace std;
//Function declerations
double getLength();

double getWidth();

double getArea(double l,double w);

void displayArea(double area);

int main()
{   //declare thev ariables and create the display format needed
    double l,w,area;
    area=getArea(l,w);
    cout<<"Rectangle Data"<<endl;
    cout<<"--------------"<<endl;
    cout<<"Length:"<<getLength() << endl; //call the functions to preform calculations
    cout << "Width:" << getWidth() << endl;
    cout << displayArea(area) << endl;
    return 0;
}
//function to get length from user
double getLength()
{
    double len;
    cout<<"Enter the length:";
    cin>>len;
    return len;
}
//function to get width from user
double getWidth()
{
    double width;
    cout<<"Enter the width:";
    cin>>width;
    return width;
}
//function to take width * length and return value
double getArea(double l,double w)
{
    return l*w;
}
//function to display the value returned from get area function
void displayArea(double area)
{
    cout<<"Area:"<<area<<endl;
}

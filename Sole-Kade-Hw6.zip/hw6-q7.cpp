
 //Author : Kade Sole
 //Program : hw6 Q7


//Question - Combine your code for q4 above to print the triangles side by side.


//Pseudocode create the same style of for loops with the same shape however make them go horizontal with eachother instead of one under another. Also, use horizontal spacing to create
// a gap between the shapes. Make sure not to confuse the for loops together because its alot
#include <iostream>

using namespace std;

int main()
{
    int i, j, k, l, m;
    cout<<"All four patterns:"<<endl;

    for(i=0;i<10;i++)
        {

        for(j=i;j>=0;j--){ // pattern 1
            cout<<"*";
            }
            for(k=10;k>=i;k--){
            cout<<" ";
            }
            cout<<"\t";

        for(k=10;k>i;k--)
            { //pattern 2
            cout<<"*";
            }
            for(j=i;j>=0;j--){
            cout<<" ";
            }
            cout <<"\t";

        for(l=i;l>=0;l--)
            { // pattern 3
            cout<<" ";
            }
            for(k=10;k>i;k--){
            cout<<"*";
            }
            cout<<"\t";

            for(l=10-i;l>=0;l--)
                { //pattern 4
                cout<<" ";
                }
                for(j=i;j>=0;j--){
                cout<<"*";
                }

            cout<<"\n";
        }

return 0;
}

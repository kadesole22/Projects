
 //Author : Kade Sole
 //Program : hw6 Q15


//Question - 15 redo question 7 but without the cout << " " statements

//Use q7 as the base but remove the cout << " " statements from it


#include<stdio.h>
#include<iostream>
using namespace std;



int main ()
{
int i, j, k, l, m;
    cout<<"All four patterns:"<<endl;

    for(i=0;i<10;i++)
        {

        for(j=i;j>=0;j--){ // pattern 1
            cout<<"*";
            }
            cout<<"\t";

        for(k=10;k>i;k--)
            { //pattern 2
            cout<<"*";
            }

            cout <<"\t";

        for(l=i;l>=0;l--)
            //pattern 3
            for(k=10;k>i;k--){
            cout<<"*";
            }
            cout<<"\t";

            for(l=10-i;l>=0;l--)
                //pattern 4
                for(j=i;j>=0;j--){
                cout<<"*";
                }

            cout<<"\n";
        }

return 0;
}


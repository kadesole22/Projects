
 //Author : Kade Sole
 //Program : hw6 Q1

 //Question company wants to transmit data over the Internet but is concerned about the security of the
//sensitive data. All of the data are transmitted as four-digit integers. The company asked you
//to write a program that encrypts the data so that it can be transmitted securely. Your pro-
//gram should read a four-digit integer and encrypt it as follows: Replace each digit (the sum of
//that digit plus 7) modulus 10. Then, swap the first digit with the third, swap the second with
//the fourth and print the encrypted integer. Add decryption functionality to your program
//above that inputs an encrypted four-digit integer and decrypts it to form the original number.

//Pseudocode 1. Create 2 functions, one to encrypt the data and another to decrypt the data. Have these functions use the
//(sum of that digit plus 7 %10) to calculate the first part of the encryption then swap the first digit with third, the
// second with the fourth. Display this calculation back to the user.





#include <iostream>

using namespace std;


//Encryption Function
int encrypt(int);

//Decryption Function
int decrypt(int);

int main()
{
    //Declaration of variables
    int n, en;

    //Collect Input from user
    cout<<"Enter a four-digit number : ";
    cin>>n;

    //Call the function to calculate encrypted number
    cout<<"Encrypted number is : "<<encrypt(n);

    //collect input from user
    cout<<"\n\nEnter a encrypted number : ";
    cin>>en;

    //Call the decrypt function to calculate normal integer
    cout<<"Decrypted number is : "<<decrypt(en);
    return 0;
}
//Encrypt Function Details
int encrypt(int n)
{
    int arr[4];
    int i;
    for( i = 0 ; i < 4 ; i++ )
    arr[i] = 0;
    int index = 3;

        // loop untill n is not 0
        while(n > 0)
            {
            //Split the users integer into 4 diff integers and assign them a value to the array
            arr[index--] = n % 10;
            n /= 10;
            }
                //calculate the new integers by +7 and then %10 each integer
                for( i = 0 ; i < 4 ; i++ )
                    arr[i] = (arr[i] + 7) % 10;

                    // swap first and third digit (remember Array starts at 0)
                    int temp = arr[0];
                    arr[0] = arr[2];
                    arr[2] = temp;

                    // swap second and fourth digit (remember Array starts at 0)
                    temp = arr[1];
                    arr[1] = arr[3];
                    arr[3] = temp;
                    //return calculations
                    int ans = 1000 * arr[0] + 100 * arr[1] + 10 * arr[2] + arr[3];
                    return ans;
}

// decrypt the data function
int decrypt(int n)
{

    int arr[4];
    int i;
    for( i = 0 ; i < 4 ; i++ )
        arr[i] = 0;
        int index = 3;
        // loop untill n is not 0
        while(n > 0)
            {
            //take the users 4 digit int and turn it into 4 ints
            arr[index--] = n % 10;
            n /= 10;
            }
    // swap first and third digit
    int temp = arr[0];
    arr[0] = arr[2];
    arr[2] = temp;

    // swap second and fourth digit
    temp = arr[1];
    arr[1] = arr[3];
    arr[3] = temp;
    //calculate the decrypted number
    for( i = 0 ; i < 4 ; i++ )
        arr[i] = (arr[i] + 3) % 10;
        //return calculation  back to user
        int ans = 1000 * arr[0] + 100 * arr[1] + 10 * arr[2] + arr[3];
    return ans;

}



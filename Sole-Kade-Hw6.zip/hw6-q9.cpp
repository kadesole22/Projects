
 //Author : Kade Sole
 //Program : hw6 Q9
//Question - A common application in computer graphics, as well as in many different subfields in science
//and engineering, is to compute the distance between two points which involves Pythagorean
//theorem and hence a square root calculation. However, as accuracy of the square root in-
//creases the time to compute it also increases. Often, a very coarse granularity approximation
//of the square root is good enough. Use Babylonian method (special case of Newton�s method
//� Newton�s method is a method in calculus for determining a zero of a function) and Halley
//approximation to find crude estimates of square root of numbers. You may need to do some
//research about these algorithms.


//Psuedocode Create 3 Functions. One that calculates the square root using Halley's method. Another that calculates it using the babylonian method. And a third function that
//will represent the user input in the other two functions as well as a call to the standard sqrt function

#include <iostream>
#include <string>
#include <cmath>
using namespace std;

//decleration of functions
double halleySquareRoot(double n);
double babylonianSquareRoot(double n);
int wholeNumberOfDigits(double n);


//Main Function
int main()
{
    double number;
    cout << "Enter a number to find the square root: ";
    cin >> number;
    //Collect the input from user
    //Call to the 3 functions to return the square roots to user
    cout << endl << "Square root approximation using Babylonian method is: " << babylonianSquareRoot(number) << endl;
    cout << endl << "Square root approximation using Halley method is: " << halleySquareRoot(number) << endl;
    cout << endl << "Square root using cmath function is: " << sqrt(number) << endl;
    return 0;
}


//Function that calculates square root using Babylonian Method
double babylonianSquareRoot(double n)
{
    int digits = wholeNumberOfDigits(n);
    double x0 = pow(3, digits);
    double acc = 0.0000001;
    double x1;
    while(true)
    {
        x1 = (x0 + (n/x0)) / 2;
        if(abs(x1-x0) < acc)
        break;
        x0 = x1;
    }
    return x0;
}

//Function that calculates the square root using Halley's Method
double halleySquareRoot(double n)
{
    int digits = wholeNumberOfDigits(n);
    double x0 = pow(3, digits);
    double acc = 0.0000001;
    double x1;
    while(true)
    {
        x1 = (x0 * (x0*x0 + 3*n)) / (3*x0*x0 + n);
        if(abs(x1-x0) < acc)
        break;
        x0 = x1;
    }
    return x0;
}

//Function that calculates the new digit needed for Halley and Babylonian calculation
int wholeNumberOfDigits(double n)
{
    int total = 0;
    string num = to_string(n);
    int i = 0;
    while(num.at(i) != '.')
    {
        total++;
        i++;
    }
    return total;
}

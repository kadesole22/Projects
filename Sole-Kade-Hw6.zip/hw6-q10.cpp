
 //Author : Kade Sole
 //Program : hw6 Q10

 //Question - A company pays its employees as managers (who receive a fixed weekly salary), hourly workers
//(who receive a fixed hourly wage for up to the first 40 hours they work and time-and-a-half,
//i.e. 1.5 times their hourly wage, for overtime hours worked), commission workers (who re-
//ceive $250 plus 5% of their gross weekly sales), or pieceworkers (who receive a fixed amount
//of money for each item they produce-each pieceworker in the company works only on one
//type of item). Write a program to compute the weekly pay for each employee. You do not
//know the number of employees in advance. Each type of employee has its own pay code:
//Managers have code 1, hourly workers have code 2, commission workers 3 and pieceworkers
//4. Use a switch to compute each employee�s pay according to his/her paycode. Within the
//switch, prompt the user to enter the appropriate facts your program needs to calculate each
//employee�s pay according to the paycode.
//10

//Pseudocode Create a switch statement with options for all of the different worker types. Make the default a statement that collects the code and reruns the loop to account for any weird inputs
// make a switch statement that represents -1 for the user so they are able to exit the loop. Calculate the pay that is owed depending on the users inputs. Allow them to enter multiple codes.

#include<iostream>
#include<math.h>
using namespace std;

int main()
{   //Declare the variables
    int code, x;
    double hours;
    double pay, weeklySales, items;
    double checkamount;
    //collect first code from user
    cout << "Enter paycode (-1 to end): ";
    cin >> code;
    //Allow an early exit. If code is -1 then terminate the program
    if (code == -1){
        cout << "Thank you for using our program!";
        return 0;
}

    //loop that calculates the pay
    for (int x = code; x != -1;){
    switch (code)
    {
    case 1://Manager
        cout << "Manager selected.\n" ;
        cout << "Enter weekly salary: \n";
        cin >> checkamount;
        cout << "The manager's pay is $" << checkamount << endl;
        break;

    case 2://Hourly worker
        cout << "Hourly worker selected.\n" << "Enter the hourly salary. :";
        cin >> pay;
        cout << "Enter the total hours worked: \n";
        cin >> hours;
        cout << "Worker's pay is $" << pay*hours << endl;
        break;

    case 3://Commission worker
        cout << "Commission worker selected.\n";
        cout << "Enter gross weekly sales :";
        cin >> weeklySales;
        cout << "Commission worker's pay is $" << 250 + (.05 * weeklySales) << endl;
        break;

    case 4://Pieceworker
        cout << "pieceworker selected.\n";
        cout << "Enter number of pieces: ";
        cin >> items;
        cout << "Enter wage per piece: ";
        cin >> pay;
        cout << "Pieceworker's pay is $" << items * pay << endl;
        break;

    default://Incorrect input
        cout << "Enter pay code (-1 to end): ";
        cin >> code;
        break;

    case '-1': //I could not get this to work so i just used an if statement again
        "Thank you for using our program! ";
        break;
}   //Collect new code for next calculation
    cout << "Enter the next paycode (-1 to end):";
    cin >> code;
    //Allow termination if -1 is entered
    if (code == -1){
    cout << "Thank you for using our program!";
    return 0;
}
}
return 0;
}

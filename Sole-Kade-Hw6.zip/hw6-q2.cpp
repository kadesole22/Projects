
 //Author : Kade Sole
 //Program : hw6 Q2


//Write a program that prints a table of binary, octal and hexadecimal equivalents of the deci-
//mal numbers in the range 0 through 255

//pseudo code 1. create a for loops that iterates from 0-255 2. using the number of the current iteration its at, calculate the binary, octal, and hex form of that decimal number. 3.return these values in a table format
//make sure to have proper spacing and a header

#include <iostream>
#include<iomanip>
using namespace std;
int main()
    {
    //declaration of the variables
    int i,j,num,n=2,number,answer[8];

    //creating the header
    cout<<"Decimal Binary Octal Hex\n";
    cout<<"===============================================\n";

        //for statement to calculate the binary, octal, and hexa form of decimal numbers
        for(number=0;number<256;number++)
            {
                for(j=0;j<8;j++)
                answer[j]=0;
                i=-1;
                num=number;
                    while (num!=0)
                    {
                    i++ ;
                    answer[i]=num%n;
                    num=num/n;
                    }
                //print decimal number
                cout<<dec<<number<<"\t";

                for (j=7;j>=0;j--)
                cout<<answer[j];
                //create horizontal tabs with correct spacing to line up right as well as filling the blanks with 0's if missing
                cout<<"\t"<<oct<<setw(3)<<setfill('0')<<number
                <<"\t\t"<<hex<<setw(2)<<setfill('0')<<number<<endl;
}

system("pause");
return 0;
}


 //Author : Kade Sole
 //Program : hw6 Q13


//Question - Write a program that inputs an odd number from 1 to 35 and prints a diamond of aster-
//isks. You may only use output statements that print a single asterisk (*) or a single blank.
//Maximize the use of repetition with nested for loops and minimize the number of output
//statements. Check the input to make sure it is not an even number nor it is outside the
//range. Use do...while to ensure acceptable input value

//Pesudocode Create two functions. One to calculate the Amount of spaces that should be used and one for the * that should be used. Make sure that if an even number
// Or a number outside the range of 1-35 is entered, The interfact will prompt the user for a new value. Return the diamond shape that the two functions should create

#include<stdio.h>
#include<iostream>
using namespace std;
//decleration of the functions
void printSpace(int n );
void printAsterisks(int n);

int main ()
{   //initialize variable
    int numRows;
    //collect input from the user
    cout << "Enter an odd number for rows (1 to 35) for the diamond of asterisks: ";
    cin >> numRows;

    do {    //This is to make sure that the input is from 1-35 and an odd number
        if (numRows % 2 == 0 || numRows < 1 || numRows > 35){
            cout << numRows << " is not an odd number within the range. Please re-try:  \n";
            cin >> numRows;
        }
    } while (numRows % 2 == 0 || numRows <1 || numRows > 35);
    //Function calls to print the a portion of the stars and spaces
    for (int i = 1; i < numRows; i+=2){
        printSpace((numRows - i)/2);
        printAsterisks(i);
        cout << endl;
    } //function calls to print the final portion of stars and spaces
    printAsterisks(numRows);
    cout << endl;
    for (int i = numRows -2; i > 0; i-=2){
        printSpace((numRows-i)/2);
        printAsterisks(i);
        cout << endl;
    }
    return 0;

}   //Function definition of printSpace
    void printSpace(int n ){
        for (int i=0;i<n;i++)
            cout << " ";
        }
    //Function definition of printAsterisks
    void printAsterisks(int n ){
        for (int i = 0; i < n; i++)
            cout << "*";
        }



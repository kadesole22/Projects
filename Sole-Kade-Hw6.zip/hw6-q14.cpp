
 //Author : Kade Sole
 //Program : hw6 Q14 Extra Credit



//Question - Redo question four but without using and " " cout statements

//Use question four but remove the cout << " "; statements from the patterns

#include<stdio.h>
#include<iostream>
using namespace std;



int main ()
{
int i, j, k, l, m;
cout<<"All four patterns:"<<endl;

for(i=0;i<10;i++)
    { //1st Pattern
    int n=10;
    for(int i=0;i<n;i++)
    {
        //Loop to print *
        for(int j=0;j<(i+1);j++)
        {
            cout<<"*";
        }
        cout<<endl;
    }
    cout << "\n";


    //2nd Pattern
    for(int i=n-1;i>=0;i--)
    {
        //Loop to print *
        for(int j=0;j<i+1;j++)
        {
            cout<<"*";
        }
        cout<<endl;
    }

    //3rd pattern
    for(int i=0;i<n;i++)
    {
        //Loop to print spaces in each row
        for(int j=0;j<2*i;j++)
        //Loop to print *
        for(int j=0;j<(n-i-1)+1;j++)
        {
            cout<<"*";
        }
        cout<<endl;
    }

    //4th pattern
    for(int i=0;i<n;i++)
    {
        //Loop to print spaces in each row
        for(int j=0;j<2*(n-i-1);j++)
        //Loop to print *
        for(int j=0;j<(i)+1;j++)
        {
           cout<<"*";
        }
        cout<<endl;
    }
return 0;
}
}





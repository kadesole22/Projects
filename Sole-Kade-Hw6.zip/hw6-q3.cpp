
 //Author : Kade Sole
 //Program : hw6 Q3


//Write a program that reads five numbers (between 1 and 30). Assume that the user only en-
//ters valid values. For each number that is read, your program should output a line containing
//that number of adjacent asterisks.

//pseudo code 1. collect the users 5 inputs. 2. After gathering each input calculate the amount of * needed to match the input. For example, if user enters 2, calculate 2*
// 3. Return the * calculation back to user 4. A for loop should work to calculate these stars

#include<iostream>
using namespace std;

int main()
{   //declaration of variables
    int i,n,j;
    //get user to enter input
    cout<<"Enter 5 numbers between 1 and 30: ";
        //enter a loop that calculates the amount of * needed per number
        //let it iterate 5 times
        for(i=0;i<5;i++)
        {   //store user input locally inside the for loop
            cin>>n;
            //while j is less than input print a *
            for(j=0;j<n;j++)
                cout<<"*";
            //end line once j is not less than n and repeat previous loop
            cout<<endl;
        }
    system("pause");
    return 0;
}

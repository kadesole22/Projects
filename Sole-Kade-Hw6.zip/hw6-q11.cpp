
 //Author : Kade Sole
 //Program : hw6 Q11

 //Question -  K-12 science and engineering competition has 5 judges, each of whom awards a score
//between 0 and 10 to each project. Fractional scores, such as 8.3, are allowed. A project�s
//final score is determined by dropping the highest and lowest score received, then averaging
//the 3 remaining scores. Write a program that uses this method to calculate a contestant�s
//score. It should include the following functions: a) void getJudgeData() should ask the user
//for a judge�s score, store it in a reference parameter variable, and validate it. This function
//should be called by main once for each of the 5 judges. b) void calcScore() should calculate
//and display the average of the 3 scores that remain after dropping the highest and lowest
//scores the performer received. This function should be called just once by main, and should
//be passed the 5 scores.
//The last two functions, described below, should be called by calcScore, who uses the returned
//information to determine which of the scores to drop. c) int findLowest() should find and
//return the lowest of the 5 scores passed to it. d) int findHighest() should find and return the
//highest of the 5 scores passed to it.


//Pesudo Code create four Functions. One to get judge scores, one to calculate the score and then two functions that find the highest and lowest score.
//In the function that does the calculation, remove the highest and lowest score then average the remaining scores and return that value to user as calculation


#include <iostream>
using namespace std;
//Decleration of variables
void getJudgeData(double&);

void calcScore(double[]);

double findLowest(double[]);

double findHighest(double[]);

//Main function
int main()
{
    double scores[5];
    int i;
    for(i=0;i<5;i++)
    getJudgeData(scores[i]);
    calcScore(scores);
    system("pause");
    return 0;
}

//Function to get judge score
void getJudgeData(double& s)
{
    cout<<"Enter score between 0 and 10: ";
    cin>>s;
    while(s<0||s>10)
    {cout<<"score must be between 0 and 10\n";
    cout<<"Enter score between 0 and 10:";
    cin>>s;
    }
}
//Function to get score by removing highest and lowest than averaging
void calcScore(double s[])
{
    double low,high,tot=0,avg;
    int i;
    low=findLowest(s);
    high=findHighest(s);
    for(i=0;i<5;i++)
    tot+=s[i];
    avg=(tot-low-high)/3.;
    cout<<"This contestant's talent score is:"<<avg<<endl;
}
//Function to find lowest score
double findLowest(double s[])
{
    int i;
    double n;
    n=s[0];
    for(i=1;i<5;i++)
    if(s[i]<n)
    n=s[i];
    return n;
}
//Function to find highest score
double findHighest(double s[])
{
    int i;
    double n;
    n=s[0];
    for(i=1;i<5;i++)
    if(s[i]>n)
    n=s[i];
    return n;
}

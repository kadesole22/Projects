
 //Author : Kade Sole
 //Program : hw6 Q12


//Question - Calculate the value of pi from the infinite series.


//Pesudo Code Create a chart that displays pi with x terms from 100-1500 increasing by 100 each time should be 15 print statements from the looping

#include <iostream>
#include <iomanip>
using namespace std;
//Main function
int main()
 {
    int sign = 1;
    double pi = 0;
    cout << setprecision(15) << fixed;
    //Looping to go until i is 1500
    for(int i = 0; i < 1500; ++i)
        {   //Calculations of pi
            pi += (sign * (1.0 / (2*i + 1)));
            sign *= -1;
            //If i is divisible by 100 then print calculations
            if((i+1) % 100 == 0)
            {
                cout << "pi with " << setw(5) << (i+1) << " terms = " << pi*4 << endl;
            }
        }
    return 0;
 }

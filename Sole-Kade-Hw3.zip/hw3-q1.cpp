
 //Author : kade Sole
 //Program : hw3, q1
//determine if a number is divisible by 7







#include <iostream>
using namespace std;


int main() {
//collect number from user
int num = 0;
//begin the loop to check if divisible by 7 and return statement depending on if it is or not
while (true) {
    cout << "Enter an integer number : ";
    cin >> num;
    bool divisible = !(num % 7);
    if (divisible) {
        cout << "Your integer number: " << num << " Is divisible by 7\n" << endl;
        break;
    }
    else {
        cout << "Your integer number: " << num << " Is not divisible by 7\n";
    }
}





return 0;

}

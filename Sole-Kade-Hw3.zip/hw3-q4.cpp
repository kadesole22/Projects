
 //Author : kade Sole
 //Program : hw3, q4
//Write a program that inputs three integers from the keyboard and prints the sum, average,
//product, smallest and largest of these numbers.







#include <iostream>
using namespace std;


int main() {
int num1,num2,num3;
cout << "Enter the first number: ";
cin >> num1;
cout << "Enter the second number: ";
cin >> num2;
cout << "Enter the third number: ";
cin >> num3;

int sum = num1 + num2 + num3;

int product = num1 * num2 * num3;

int average = sum / 3.0;

int smallest = num1;

if(num2<smallest)
smallest = num2;

if(num3<smallest)
smallest = num3;

int largest = num1;

if(num2>largest)
largest = num2;

if(num3>largest)
largest = num3;

cout << "The sum is: " << sum << endl;
cout << "Average is: " << average << endl;
cout << "Product is: " << product << endl;
cout << "The smallest number is: " << smallest << endl;
cout << "The largest number is: " << largest << endl;





return 0;

}

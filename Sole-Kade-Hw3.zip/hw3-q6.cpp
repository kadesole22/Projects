
 //Author : kade Sole
 //Program : hw3, q6
//Write a program that displays the following menu:
//Geometry Calculator
//1. Calculate the Area of a Circle
//2. Calculate the Area of a Rectangle
//3. Calculate the Area of a Triangle
//4. Quit
//then calculate these and give the outputs






#include <iostream>
using namespace std;


int main() {
int choice;
cout << "Geometry Calculator \n\n\nEnter 1 to calculate the area of a circle\nEnter 2 to calculate the area of a rectangle\nEnter 3 to calculate the area of a triangle\nEnter 4 to quit";
cin >> choice;

float area;
switch(choice)
{
case 1:
    float r;
    cout << "Enter the radius of a circle: ";
    cin >> r;
    if(r > 0){
        area = (3.14159 * (r * r));
        cout << "Area of the circle is: " << area << endl;}
        else if (r < 0) {
        cout << "The radius can not be less than zero.\n";}
        break;
case 2:
    float length,width;
    cout<<"Enter length: ";
    cin>>length;
    cout<<"Enter width: ";
    cin>>width;
    area = length * width;
    if(length > 0 && width > 0){
    cout<<"Area of Rectangle is: " << area << endl;}
    else if (length < 0 or width < 0);{
            cout << "must be a positive number for length and width values\n";}
            break;
case 3:
    float height,base;
    cout<<"Enter base: ";
    cin>>base;
    cout<<"Enter height: ";
    cin>>height;
    area=(base*height)/2;
    if (base > 0  && height > 0){
    cout<<"Area of Triangle is: "<<area<<endl;}
    else if (base < 0){
            cout << "Only enter positive values for base and height\n";}
    else if (height < 0) {cout << "Only enter positive values for base and height\n"; }
    break;
case 4:
    cout << "Bye!";
    break;

case 8:
    cout << "You may only enter 1, 2, 3, or 4";

}

return 0;
}

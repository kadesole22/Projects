
 //Author : kade Sole
 //Program : hw3, q2
//Write a program that reads two integers from the keyboard and prints if the first is a multiple
//of the second. Hint: Use modulus operator.







#include <iostream>
using namespace std;


int main() {

int first, second; //declaring the variables i plan to use

cout << "Enter The First Integer: ";
cin >> first; // get the first input from the user

cout << "Enter The Second Integer: ";
cin >> second;

if(first % second == 0 )
{
    cout << first << " Is evenly divisible by " << second << endl;
}
else
     cout << first << " Is NOT evenly divisible by " << second << endl;





return 0;

}


 //Author : kade Sole
 //Program : hw3, q3
//Modify the hw1, q1 program so that it prints out the letter grade based on the grading scale
//of this class available on the syllabus.







#include <iostream>
using namespace std;


int main() {
int hw1;
cout<<"Enter your Hw1 Grade (out of 100)";
cin>> hw1;

//collect hw2 grade
int hw2;
cout<<"Enter your Hw2 Grade (out of 100)";
cin>> hw2;

//collect hw3 grade
int hw3;
cout<<"Enter your Hw3 Grade (out of 100)";
cin>> hw3;

//collect midterm grade
int midterm;
cout<<"Enter your Midterm grade(out of 100)";
cin>> midterm;

//collect final exam grade
int finalexam;
cout<<"Enter your Final Exam grade(out of 100)";
cin>> finalexam;

//calculates weight
int hw_1 = (hw1 * .1);
int hw_2 = (hw2 * .1);
int hw_3 = (hw3 * .1);
int mid_term = (midterm * .3);
int final_exam = (finalexam * .4);

//calculates overall grade
int overall_grade = int(hw_1)+int(hw_2)+int(hw_3)+int(mid_term)+int(final_exam);

 if(overall_grade>=97 && overall_grade<=100)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : A+";
    else if(overall_grade>=92 && overall_grade <96)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : A";
    else if(overall_grade>=90 && overall_grade <91)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : A-";
    else if(overall_grade>=88 && overall_grade <89)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : B+";
    else if(overall_grade>=82 && overall_grade <87)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : B";
    else if(overall_grade>=80 && overall_grade <81)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : B-";
    else if(overall_grade>=78 && overall_grade <79)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : C+";
    else if(overall_grade>=72 && overall_grade <77)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : C";
    else if(overall_grade>=70 && overall_grade <71)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : C-";
    else if(overall_grade>=68 && overall_grade <69)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : D+";
    else if(overall_grade>=60 && overall_grade <67)
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : D";
    else
        cout<<"Overall Grade: " << overall_grade << " Out of 100\n" << "Your letter grade is : E";
    cout<<endl;





return 0;

}


 //Author : kade Sole
 //Program : hw3, q5
//Write a program that reads in the quiz scores of a class of ten students. The grades are
//integers in the range of 0-100. If the grade entered is not within this range, reject and ask
//for a number in the range. Calculate and display the total of all student grades and calculate
//the average.






#include <iostream>
using namespace std;


int main() {
int grade_1,grade_2,grade_3,grade_4,grade_5,grade_6,grade_7,grade_8,grade_9,grade_10;
cout << "Enter Grade 1: ";
cin >> grade_1;

cout << "Enter Grade 2: ";
cin >> grade_2;

cout << "Enter Grade 3: ";
cin >> grade_3;

cout << "Enter Grade 4: ";
cin >> grade_4;

cout << "Enter Grade 5: ";
cin >> grade_5;

cout << "Enter Grade 6: ";
cin >> grade_6;

cout << "Enter Grade 7: ";
cin >> grade_7;

cout << "Enter Grade 8: ";
cin >> grade_8;

cout << "Enter Grade 9: ";
cin >> grade_9;

cout << "Enter Grade 10: ";
cin >> grade_10;

 if (int(grade_1) >= 0 && int(grade_1) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_1 << "is not in the range of 0-100 try again!";


if (int(grade_2) >= 0 && int(grade_2) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_2 << "is not in the range of 0-100 try again!";


if (int(grade_3) >= 0 && int(grade_3) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_3<< "is not in the range of 0-100 try again!";


if (int(grade_4) >= 0 && int(grade_4) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_4 << "is not in the range of 0-100 try again!";


 if (int(grade_5) >= 0 && int(grade_5) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_5 << "is not in the range of 0-100 try again!";


if (int(grade_6) >= 0 && int(grade_6) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_6 << "is not in the range of 0-100 try again!";


if (int(grade_7) >= 0 && int(grade_7) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_7 << "is not in the range of 0-100 try again!";


if (int(grade_8) >= 0 && int(grade_8) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_8 << "is not in the range of 0-100 try again!";


if (int(grade_9) >= 0 && int(grade_9) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_9 << "is not in the range of 0-100 try again!";


if (int(grade_10) >= 0 && int(grade_10) <= 100)
        cout << "\nAll Good";
        else
            cout << "\nSorry!" << grade_10 << "is not in the range of 0-100 try again!";


int sum = grade_1 + grade_2 + grade_3 + grade_4 + grade_5 + grade_6 + grade_7 + grade_8 + grade_9 + grade_10;

int avg = sum / 10;
cout << "\nTotal is: " << sum <<endl;
cout << "\nAverage is: " << avg << endl;



}

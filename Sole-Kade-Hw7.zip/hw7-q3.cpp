
 //Author : Kade Sole
 //Program : hw7, q3

//Question - Write a program to calculate the factorial by means of a function. Note: The result will not be
//accurate for relatively larger numbers with the built-in C++ data types. We will implement the
//accurate one later with arrays.

//Pseudo Code Create a function that calculates and returns the factorial of the int that a user input. In the main func ask user for an input
// Then call the function with the input user game as an argument and calculate the factorial

#include<stdio.h>
#include<iostream>
using namespace std;

//Function prototype
long getFact(int num);

//Main function
int main ()
{   //Variable decleration
    int input;
    //gets input from user and stores it
    cout << "Enter a number for factorial computation and press ENTER ";
    cin >> input;
    //Function call to calculate the factorial of input
    long result = getFact(input);
    //Return the result back to user
    cout << input << "!(by Factorial Function) is " << result << endl;

    return 0;

}
//Function definition
long getFact(int num){
    long fact = 1;
    int i = 2;
    while (i <= num)
    {
        fact *= i;
        i++;
    }
    return fact;
}

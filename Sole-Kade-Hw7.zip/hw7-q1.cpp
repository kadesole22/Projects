
 //Author : Kade Sole
 //Program : hw7, q1

//Question - Write a program that simulates a coin tossing. For each toss of the coin, the program should print
//Heads or Tails. Let the program toss the coin 200 times and count the number of times each side of
//the coin appears. Print the results. The program should call a separate function (flip) that takes no
//arguments and returns 0 for tails and 1 for heads

//Pseudo Code 1. use a for loop that iterates 200 times for all coin toss trials 2.In the function take a random number and checks if its odd or even If its even, store as heads
// If its odd store as tails. Count how many even and odds there are out of the 200 trials and display these as heads and tails

#include<stdio.h>
#include<iostream>
using namespace std;
//Function Prototype
int flip(void);
//Main Function
int main (){
    //Variable Decleration
    int head = 0;
    int tails = 0;
    int i;
    //For loop for 200 iterations
    for (i = 1 ; i < 201; i++){
        //Function call
        if (flip()){
            cout << "Tails ";
            tails += 1;
            }
        else{
            cout << "Heads ";
            head += 1;
            }
        //Used to create rows
        if (i % 10 == 0)
            cout << "\n";
        }
    //Return head count to user
    cout << "\n The total number of heads was: " << head << endl;
    //Return tail count to user
    cout << "The total number of tails was:" << tails << endl;

    return 0;
}
//Function definition
int flip(void){
    return rand() % 2;
    }

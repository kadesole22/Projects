
 //Author : Kade Sole
 //Program : hw7,q4

//Question - Write a program that gets a integer from user and prints all ints from 1 to input in a function

//Pseudocode In the Main function ask user for integer. Use this in the function to display numbers from 1 - input user gave
#include<stdio.h>
#include<iostream>
using namespace std;
//Function prototype
string intPrint(int x);
//Main Function
int main ()
{
    //Variable Initialization
    int z;
    //Print statement to get input from user
    cout << "Enter an integer (to print all whole numbers from 1 to that number) : ";
    cin >> z;
    //Function call
    intPrint(z);
    return 0;
}
//Function definition
string intPrint(int x){
    //initialize counter
    int j;
    //make counter start at 1 and go to j
    for (j = 1; j <= x; j++)
    cout << j << " ";



    }

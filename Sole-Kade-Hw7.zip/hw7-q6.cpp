
 //Author : Kade Sole
 //Program : hw7, q6


//Question - Write a program that finds the first prime number greater than one billion

// Create an infinite loop that starts at 1 billion and continues checking until a prime number is found. Once its found, exit loop and return integer to user.
#include<stdio.h>
#include<iostream>
using namespace std;



int main ()
{
    int number = 1000000000, i;
    bool prime, done = false;


    //Infinite loop because done = false
    while (!done){

        prime = true;

        for ( i = 2; i <= number/2; i++)
            //Check if its prime
             if (number % i == 0)
                prime = false;
            //if prime reads true at this point, we found the number
             if(prime)
             {  //exit the loop because done = true now
                 done = true;
                 cout << number << " is the first prime number after 1 billion";
             }
              number ++;
         }
         return 0;
    }

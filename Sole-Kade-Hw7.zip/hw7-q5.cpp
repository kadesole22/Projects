
 //Author : Kade Sole
 //Program : hw7,q5


//Question - Write a program that will check and print if the numbers from 1 to 20 are prime or not as shown below. Implement checking the primeness in a function

// 1. Create a function that checks if user input is a prime number 2. I want to use a true or false statement, True if it is a prime number and false if it isnt. If function returns false print that its not prime, if it returns true
//print that it is


#include <iostream>
using namespace std;
//Function Prototype
bool is_prime(int n);
//Main Function
int main()
{
    //go from 1 to 20 calc if prime
   for(int i = 1; i <= 20; ++i)
        {
            if(is_prime(i))
            {
                cout << i << " is prime" << endl;
            }
            else
            {
                cout << i << " is not prime" << endl;
            }
        }
   return 0;
}

//Func that calculates if n is prime and returns a true or false statement
bool is_prime(int n) {
   int i;
   for(i = 2; i < n; ++i) {
      if(n % i == 0) {
         return false;
      }
   }
   return true;
}
